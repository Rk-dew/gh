import type React from 'react';
import { Link } from 'react-router-dom';

const NAV_LINKS = [
  { name: 'Hire Talent', href: '/hire-talent' },
  { name: 'Discover Jobs', href: '/discover-jobs' },
  { name: 'Pricing', href: '/pricing' },
  { name: 'Partners', href: '/partners' },
];

const Header = () => (
  <header className="w-full h-20 bg-white border-b flex items-center justify-center px-4 lg:px-16 fixed top-0 left-0 right-0 z-30">
    <nav className="w-full max-w-7xl flex items-center justify-between gap-4">
      {/* Logo */}
      <Link to="/" className="shrink-0 flex items-center gap-2" aria-label="Home">
        <img src="https://ext.same-assets.com/3534922414/3877185713.svg" alt="SupportFinity Logo" className="h-8 w-auto" />
      </Link>
      {/* Nav links - desktop */}
      <div className="hidden lg:flex gap-4 ml-4">
        {NAV_LINKS.map((link) => (
          <Link
            key={link.href}
            to={link.href}
            className="text-[#0b0c10] hover:text-[#2faa94] font-medium px-3 py-2 rounded transition-colors duration-150"
          >
            {link.name}
          </Link>
        ))}
      </div>
      {/* Call to Action - desktop */}
      <div className="ml-auto flex gap-2 items-center">
        <Link to="/login" className="hidden lg:inline-block text-[#3433da] font-semibold px-4 py-2 rounded hover:underline">
          Log In
        </Link>
        <Link
          to="/hire-talent"
          className="inline-block bg-[#2faa94] hover:bg-[#251f55] text-white font-bold px-5 py-2 rounded-full transition-colors duration-150 shadow"
        >
          Get Started
        </Link>
      </div>
      {/* Mobile nav (horizontal scrollable links and actions) */}
      <div className="flex lg:hidden gap-2 ml-auto">
        <button className="inline-flex items-center px-3 py-2 border rounded text-[#2faa94] border-[#2faa94] focus:outline-none">
          <svg className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" /></svg>
        </button>
      </div>
    </nav>
  </header>
);

const Footer = () => <footer className="w-full min-h-16 bg-[#eef0f3] border-t" />;

const MainLayout = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen flex flex-col bg-white">
    <Header />
    <main className="flex-1 pt-20">{children}</main>
    <Footer />
  </div>
);

export default MainLayout;
