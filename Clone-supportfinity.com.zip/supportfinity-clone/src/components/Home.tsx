import React from "react";

const HERO_IMG =
  "https://ext.same-assets.com/3534922414/1150846705.png";
const LOGOS = [
  {
    src: "https://ext.same-assets.com/3534922414/798262813.svg",
    alt: "CNN"
  },
  {
    src: "https://ext.same-assets.com/3534922414/476754891.svg",
    alt: "Entrepreneur"
  },
  {
    src: "https://ext.same-assets.com/3534922414/3496147334.svg",
    alt: "TechCrunch"
  },
  {
    src: "https://ext.same-assets.com/3534922414/2484978658.svg",
    alt: "Forbes"
  },
  {
    src: "https://ext.same-assets.com/3534922414/916457381.svg",
    alt: "Business Insider"
  }
];

const FEATURES = [
  {
    title: "AI-Vetting & Fast Sourcing",
    desc: "Instantly match & verify candidates using AI, saving you hours of manual efforts.",
    img: "https://ext.same-assets.com/3534922414/1529604768.png"
  },
  {
    title: "Modern ATS & CRM",
    desc: "Streamline applications, automate outreach, schedule interviews — all-in-one platform.",
    img: "https://ext.same-assets.com/3534922414/1845319699.png"
  },
  {
    title: "Assessments Marketplace",
    desc: "Choose from 1,000s of validated tests and skill checks to screen top talent.",
    img: "https://ext.same-assets.com/3534922414/2461774366.png"
  },
  {
    title: "Branded Job Board",
    desc: "Showcase your company, attract the best, and manage postings with advanced analytics.",
    img: "https://ext.same-assets.com/3534922414/1150846705.png"
  }
];

const WORKFLOW = [
  {
    step: 1,
    title: "Post a Job or Search",
    desc: "Create a branded job or search the marketplace instantly.",
    icon: "https://ext.same-assets.com/3534922414/815793862.svg"
  },
  {
    step: 2,
    title: "AI-Match & Vet",
    desc: "Let AI instantly find, rank, and verify candidate fit.",
    icon: "https://ext.same-assets.com/3534922414/3877185713.svg"
  },
  {
    step: 3,
    title: "Assess & Collaborate",
    desc: "Evaluate with assessments, share profiles, or interview via platform tools.",
    icon: "https://ext.same-assets.com/3534922414/3372430981.svg"
  },
  {
    step: 4,
    title: "Hire with Confidence",
    desc: "Make offers, onboard, and manage all hires seamlessly.",
    icon: "https://ext.same-assets.com/3534922414/3929955662.svg"
  },
];

const CUSTOMERS = [
  { src: 'https://ext.same-assets.com/3534922414/1145911389.svg', alt: 'Microsoft' },
  { src: 'https://ext.same-assets.com/3534922414/2461774366.png', alt: 'HBOX' },
  { src: 'https://ext.same-assets.com/3534922414/3929955662.svg', alt: 'Remotivate' },
  { src: 'https://ext.same-assets.com/3534922414/2332724245.svg', alt: 'Systems' },
  // Add more as found in site/asset list
];

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="w-full bg-[#eef0f3] pt-8 pb-4 lg:pt-16 min-h-[600px] flex flex-col md:flex-row items-center justify-center relative overflow-x-clip">
        <div className="max-w-7xl w-full flex flex-col md:flex-row items-center justify-between px-4 xl:px-0 mx-auto gap-y-14 md:gap-y-0">
          {/* Text content */}
          <div className="flex-1 min-w-[290px] flex flex-col items-start gap-6 z-10 md:pr-6">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#251f55] leading-tight max-w-[580px]">
              The Super <span className="text-[#2faa94]">AI-powered</span> <br /> Recruitment Platform
            </h1>
            <p className="mt-2 text-[#2b5c67] text-lg md:text-xl max-w-md font-medium">
              Find & hire the best talent with AI. Job board, sourcing, ATS, CRM, assessments. Premium. Secure. FREE. Start at Zero Risk.
            </p>
            <div className="flex gap-5 mt-4">
              <a
                href="#"
                className="bg-[#2faa94] hover:bg-[#251f55] text-white font-bold px-7 py-3 rounded-full text-lg shadow transition-colors duration-200"
              >
                Try for Free
              </a>
            </div>
          </div>
          {/* Hero image */}
          <div className="flex-1 flex justify-center items-center relative min-w-[320px] w-full">
            <img
              src={HERO_IMG}
              alt="Applicant profile preview"
              className="max-h-[410px] w-auto rounded-2xl shadow-xl border border-[#e0e5ea] bg-white drop-shadow-lg z-10"
              style={{ boxShadow: '0 12px 60px 0 rgba(52,51,218,0.08)' }}
            />
          </div>
        </div>
      </section>
      {/* Trust Logos Section */}
      <section className="w-full flex flex-col items-center justify-center bg-[#eef0f3] pb-3">
        <div className="text-gray-500 text-center text-sm pb-2">As seen in</div>
        <div className="flex flex-wrap justify-center items-center gap-x-8 gap-y-2">
          {LOGOS.map((logo) => (
            <img
              key={logo.src}
              src={logo.src}
              alt={logo.alt}
              className="h-7 w-auto grayscale hover:grayscale-0 transition-all"
              loading="lazy"
            />
          ))}
        </div>
      </section>
      {/* Features Section */}
      <section className="w-full py-16 bg-white flex flex-col items-center justify-center">
        <div className="max-w-7xl w-full px-4 xl:px-0 mx-auto">
          <h2 className="text-center text-3xl sm:text-4xl font-extrabold text-[#251f55] mb-10">
            All-in-one recruitment, solved.
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-7">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="flex flex-col bg-[#eef0f3] rounded-2xl shadow-lg border border-[#e5e7eb] p-6 items-center min-h-[350px] transition-transform hover:-translate-y-1 hover:shadow-xl"
              >
                <img
                  src={f.img}
                  alt={f.title}
                  className="h-32 w-auto mb-5 rounded-xl object-contain shadow"
                  loading="lazy"
                />
                <h3 className="text-xl font-bold text-[#2faa94] mb-2 text-center">{f.title}</h3>
                <div className="text-[#2b5c67] text-base text-center font-medium">{f.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* Workflow/How It Works Section */}
      <section className="w-full py-16 bg-[#eef0f3] flex flex-col items-center justify-center">
        <div className="max-w-7xl w-full px-4 xl:px-0 mx-auto">
          <h2 className="text-center text-2xl sm:text-3xl font-extrabold text-[#251f55] mb-10">
            How SupportFinity works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-7">
            {WORKFLOW.map((w) => (
              <div
                key={w.step}
                className="flex flex-col bg-white rounded-2xl border border-[#e5e7eb] shadow p-6 items-center min-h-[270px] transition-transform hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="flex flex-col items-center mb-4">
                  <span className="flex items-center justify-center h-12 w-12 rounded-full bg-[#2faa94]/10 mb-2">
                    <img src={w.icon} alt={w.title} className="h-7 w-7 object-contain" />
                  </span>
                  <span className="text-xs font-semibold text-[#2faa94]">Step {w.step}</span>
                </div>
                <h3 className="text-lg font-bold text-[#251f55] text-center mb-2">{w.title}</h3>
                <div className="text-[#2b5c67] text-base text-center font-medium">{w.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* Customers/Partners Logos */}
      <section className="w-full py-8 bg-white flex flex-col items-center justify-center">
        <div className="max-w-7xl w-full px-4 xl:px-0 mx-auto">
          <h2 className="text-center text-lg sm:text-xl font-semibold text-[#251f55] mb-8">
            Trusted by innovative teams worldwide
          </h2>
          <div className="flex flex-wrap gap-x-12 gap-y-6 justify-center items-center">
            {CUSTOMERS.map((logo) => (
              <img
                key={logo.src}
                src={logo.src}
                alt={logo.alt}
                className="h-10 w-auto grayscale hover:grayscale-0 transition-all rounded"
                loading="lazy"
              />
            ))}
          </div>
        </div>
      </section>
      {/* CTA Footer */}
      <section className="w-full py-16 bg-[#3433da] text-white flex items-center justify-center">
        <div className="max-w-2xl mx-auto flex flex-col items-center text-center gap-5">
          <h2 className="text-3xl sm:text-4xl font-extrabold mb-2">Start hiring smarter — for free</h2>
          <div className="text-md md:text-lg text-[#eef0f3] mb-4">
            Try SupportFinity risk-free. <br className="hidden sm:block" /> Find, match, and hire top talent with AI instantly.
          </div>
          <a
            href="#"
            className="bg-[#2faa94] hover:bg-[#d6425b] text-white font-bold px-8 py-3 rounded-full text-lg shadow-lg transition-colors duration-150 mt-2"
          >
            Get Started, Free
          </a>
        </div>
      </section>
    </div>
  );
}
