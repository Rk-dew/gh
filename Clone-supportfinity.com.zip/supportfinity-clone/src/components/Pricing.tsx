import React from 'react';
const Pricing = () => <div>Pricing Page</div>;
export default Pricing;
