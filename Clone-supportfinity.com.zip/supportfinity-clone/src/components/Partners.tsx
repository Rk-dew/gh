import React from 'react';
const Partners = () => <div>Partners Page</div>;
export default Partners;
