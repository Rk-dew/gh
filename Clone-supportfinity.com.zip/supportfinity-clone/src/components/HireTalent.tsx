import React from 'react';
const HireTalent = () => <div>Hire Talent Page</div>;
export default HireTalent;
