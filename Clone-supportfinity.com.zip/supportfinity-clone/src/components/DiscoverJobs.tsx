import React from 'react';
const DiscoverJobs = () => <div>Discover Jobs Page</div>;
export default DiscoverJobs;
