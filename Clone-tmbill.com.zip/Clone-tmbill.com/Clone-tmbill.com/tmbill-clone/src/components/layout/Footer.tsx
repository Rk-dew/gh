import Link from "next/link";
import { Facebook, Twitter, Instagram, Linkedin, Youtube } from "lucide-react";
import { TMBillLogo } from "../ui/TMBillLogo";

const footerLinks = [
  {
    title: "Products",
    links: [
      { label: "Restaurant POS", href: "#pos" },
      { label: "Online Ordering", href: "#ordering" },
      { label: "Inventory Management", href: "#inventory" },
      { label: "CRM & Loyalty", href: "#crm" },
      { label: "Table Management", href: "#tables" },
      { label: "Self-Ordering Kiosk", href: "#kiosk" },
    ],
  },
  {
    title: "Solutions",
    links: [
      { label: "Restaurants", href: "#restaurants" },
      { label: "Cafes", href: "#cafes" },
      { label: "Food Trucks", href: "#food-trucks" },
      { label: "Cloud Kitchens", href: "#cloud-kitchens" },
      { label: "Bakeries", href: "#bakeries" },
      { label: "Fine Dining", href: "#fine-dining" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Blog", href: "#blog" },
      { label: "Help Center", href: "#help" },
      { label: "Case Studies", href: "#case-studies" },
      { label: "Webinars", href: "#webinars" },
      { label: "API Documentation", href: "#api" },
      { label: "Partner Program", href: "#partners" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About Us", href: "#about" },
      { label: "Careers", href: "#careers" },
      { label: "Contact Us", href: "#contact" },
      { label: "Privacy Policy", href: "#privacy" },
      { label: "Terms of Service", href: "#terms" },
      { label: "Security", href: "#security" },
    ],
  },
];

const socialLinks = [
  { label: "Facebook", icon: <Facebook size={18} />, href: "#facebook" },
  { label: "Twitter", icon: <Twitter size={18} />, href: "#twitter" },
  { label: "Instagram", icon: <Instagram size={18} />, href: "#instagram" },
  { label: "LinkedIn", icon: <Linkedin size={18} />, href: "#linkedin" },
  { label: "YouTube", icon: <Youtube size={18} />, href: "#youtube" },
];

export function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200">
      <div className="container py-12 md:py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-6 gap-8">
          <div className="lg:col-span-2">
            <Link href="/" className="inline-block mb-6">
              <TMBillLogo />
            </Link>
            <p className="text-gray-600 mb-6 max-w-md">
              TMBill is a complete restaurant management platform trusted by
              12,000+ businesses worldwide to streamline operations and increase
              revenue.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <Link
                  key={social.label}
                  href={social.href}
                  className="h-10 w-10 flex items-center justify-center rounded-full bg-gray-100 text-gray-600 hover:bg-primary hover:text-white transition-colors"
                  aria-label={social.label}
                >
                  {social.icon}
                </Link>
              ))}
            </div>
          </div>

          {footerLinks.map((section) => (
            <div key={section.title} className="space-y-4">
              <h4 className="font-semibold text-gray-900">{section.title}</h4>
              <ul className="space-y-3">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-gray-600 hover:text-primary transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <p className="text-gray-500 text-sm">
              &copy; {new Date().getFullYear()} TMBill. All rights reserved.
            </p>
            <div className="mt-4 md:mt-0 flex flex-wrap gap-x-8 gap-y-3">
              <Link href="#privacy" className="text-gray-600 hover:text-primary text-sm">
                Privacy Policy
              </Link>
              <Link href="#terms" className="text-gray-600 hover:text-primary text-sm">
                Terms of Service
              </Link>
              <Link href="#cookies" className="text-gray-600 hover:text-primary text-sm">
                Cookie Policy
              </Link>
              <Link href="#security" className="text-gray-600 hover:text-primary text-sm">
                Security
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
