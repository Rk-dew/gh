import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Store,
  Smartphone,
  Package,
  Users,
  Clock,
  FileSpreadsheet,
  ShoppingCart,
  Truck,
} from "lucide-react";

const features = [
  {
    title: "Restaurant POS",
    description:
      "Easy-to-use point of sale system designed specifically for restaurants, with fast order taking and payment processing.",
    icon: <Store className="h-6 w-6" />,
  },
  {
    title: "Online Ordering",
    description:
      "Create your own branded food ordering website and mobile app to receive orders directly without commission.",
    icon: <Smartphone className="h-6 w-6" />,
  },
  {
    title: "Inventory Management",
    description:
      "Track ingredients, manage stock levels, and reduce waste with real-time inventory control and reports.",
    icon: <Package className="h-6 w-6" />,
  },
  {
    title: "CRM & Loyalty",
    description:
      "Build customer relationships with integrated loyalty programs, personalized offers, and customer insights.",
    icon: <Users className="h-6 w-6" />,
  },
  {
    title: "Table Management",
    description:
      "Efficiently manage tables, reservations, and wait times with visual floor plans and real-time updates.",
    icon: <Clock className="h-6 w-6" />,
  },
  {
    title: "Reporting & Analytics",
    description:
      "Get actionable insights with detailed reports on sales, menu performance, staff efficiency, and more.",
    icon: <FileSpreadsheet className="h-6 w-6" />,
  },
  {
    title: "Self-Ordering Kiosk",
    description:
      "Reduce wait times and staff costs with self-service kiosks that integrate directly with your kitchen.",
    icon: <ShoppingCart className="h-6 w-6" />,
  },
  {
    title: "Delivery Management",
    description:
      "Manage your delivery fleet or integrate with third-party delivery services for seamless order fulfillment.",
    icon: <Truck className="h-6 w-6" />,
  },
];

export function FeaturesSection() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            All-in-One Restaurant Management Platform
          </h2>
          <p className="text-lg text-gray-600">
            Streamline your restaurant operations with our comprehensive suite of
            integrated tools designed specifically for food businesses.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature) => (
            <Card key={feature.title} className="border-none shadow-sm hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center text-primary mb-4">
                  {feature.icon}
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Explore All Features
          </Button>
        </div>
      </div>
    </section>
  );
}
