import { Button } from "@/components/ui/button";

export function CTASection() {
  return (
    <section className="py-16">
      <div className="container">
        <div className="tmbill-gradient rounded-3xl p-8 md:p-12 lg:p-16 text-white">
          <div className="md:flex md:items-center md:justify-between">
            <div className="md:max-w-2xl">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Ready to Transform Your Restaurant Operations?
              </h2>
              <p className="text-lg opacity-90 mb-8">
                Join 12,000+ restaurants worldwide that use TMBill to streamline operations,
                reduce costs, and delight customers. Start free and upgrade anytime.
              </p>
              <div className="grid sm:grid-cols-2 gap-4 max-w-xl">
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="text-2xl font-bold mb-1">Free Forever</div>
                  <p className="opacity-90">
                    Start with our free plan for small businesses with basic features
                  </p>
                </div>
                <div className="bg-white/10 rounded-lg p-4">
                  <div className="text-2xl font-bold mb-1">24/7 Support</div>
                  <p className="opacity-90">
                    Our global team is ready to help you anytime, anywhere
                  </p>
                </div>
              </div>
            </div>
            <div className="mt-8 md:mt-0 md:ml-8 lg:ml-16 flex flex-col gap-4 min-w-48">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 w-full">
                Get Started Free
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white/10 w-full"
              >
                Book a Demo
              </Button>
              <p className="text-center text-sm opacity-80 mt-2">
                No credit card required
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
