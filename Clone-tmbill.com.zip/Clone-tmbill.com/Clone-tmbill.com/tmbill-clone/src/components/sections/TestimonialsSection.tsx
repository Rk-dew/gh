import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";

const testimonials = [
  {
    quote:
      "TMBill has simplified our restaurant operations significantly. The POS is intuitive, and the inventory management system has cut our food waste by 30%.",
    author: "Rajesh Kumar",
    position: "Owner, Spice Garden Restaurant",
    initials: "RK",
  },
  {
    quote:
      "The online ordering platform has increased our revenue by 25%. The direct integration with our POS saves us time and reduces errors.",
    author: "Sarah Johnson",
    position: "Manager, Cafe Delight",
    initials: "SJ",
  },
  {
    quote:
      "Customer support is exceptional. Whenever we've had questions, the TMBill team has been responsive and helpful. Great service!",
    author: "Mohammed Al-Faisal",
    position: "Owner, Al Madina Grill",
    initials: "MA",
  },
  {
    quote:
      "We've been using TMBill for over 2 years now. The continuous updates and new features keep improving our efficiency and customer experience.",
    author: "David Chen",
    position: "Operations Director, Asian Fusion Group",
    initials: "DC",
  },
];

export function TestimonialsSection() {
  return (
    <section className="py-16">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            What Our Customers Say
          </h2>
          <p className="text-lg text-gray-600">
            Join thousands of satisfied restaurant owners who have transformed
            their business with TMBill.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.author} className="border border-gray-100 shadow-sm">
              <CardContent className="p-6">
                <div className="flex flex-col h-full">
                  <div className="mb-4">
                    <svg
                      className="h-8 w-8 text-primary opacity-50"
                      fill="currentColor"
                      viewBox="0 0 32 32"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M9.352 4C4.456 7.456 1 13.12 1 19.36c0 5.088 3.072 8.064 6.624 8.064 3.36 0 5.856-2.688 5.856-5.856 0-3.168-2.208-5.472-5.088-5.472-.576 0-1.344.096-1.536.192.48-3.264 3.552-7.104 6.624-9.024L9.352 4zm16.512 0c-4.8 3.456-8.256 9.12-8.256 15.36 0 5.088 3.072 8.064 6.624 8.064 3.264 0 5.856-2.688 5.856-5.856 0-3.168-2.304-5.472-5.184-5.472-.576 0-1.248.096-1.44.192.48-3.264 3.456-7.104 6.528-9.024L25.864 4z" />
                    </svg>
                  </div>
                  <p className="text-gray-700 mb-6 flex-grow">{testimonial.quote}</p>
                  <div className="flex items-center mt-4">
                    <Avatar className="h-10 w-10 bg-primary/10 text-primary">
                      <AvatarFallback>{testimonial.initials}</AvatarFallback>
                    </Avatar>
                    <div className="ml-3">
                      <h5 className="font-medium text-gray-900">{testimonial.author}</h5>
                      <p className="text-sm text-gray-500">{testimonial.position}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex flex-wrap justify-center gap-x-6 gap-y-3">
            <div className="text-gray-400 text-sm font-medium px-4 py-2">Trusted by 12,000+ businesses worldwide</div>
            {["Restaurants", "Cafes", "Food Trucks", "Cloud Kitchens", "Bakeries", "Fast Food"].map((type) => (
              <div key={type} className="text-gray-500 text-sm font-medium px-4 py-2">
                {type}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
