import Image from "next/image";
import { Button } from "@/components/ui/button";

function ProductShowcase() {
  return (
    <div className="relative flex justify-center">
      <div className="bg-gray-800 rounded-lg shadow-2xl overflow-hidden">
        <div className="relative h-[300px] md:h-[380px] w-full max-w-[580px]">
          <div className="absolute top-0 left-0 right-0 h-8 bg-gray-700 flex items-center px-3">
            <div className="flex space-x-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
            </div>
          </div>
          <div className="pt-8 px-3 h-full bg-gray-900">
            <div className="grid grid-cols-6 h-full">
              {/* Sidebar */}
              <div className="col-span-1 bg-gray-800 rounded-tl-md p-2">
                <div className="h-8 w-full bg-primary/20 rounded mb-2"></div>
                <div className="h-8 w-full bg-gray-700 rounded mb-2"></div>
                <div className="h-8 w-full bg-gray-700 rounded mb-2"></div>
                <div className="h-8 w-full bg-gray-700 rounded mb-2"></div>
              </div>

              {/* Main content */}
              <div className="col-span-5 p-2">
                <div className="flex justify-between mb-3">
                  <div className="h-8 w-28 bg-primary rounded"></div>
                  <div className="h-8 w-28 bg-gray-700 rounded"></div>
                </div>

                {/* Table grid */}
                <div className="grid grid-cols-4 gap-2">
                  {Array.from({ length: 8 }).map((_, idx) => (
                    <div key={idx} className="h-20 bg-gray-800 rounded p-2">
                      <div className="h-4 w-full bg-gray-700 rounded mb-2"></div>
                      <div className="h-4 w-3/4 bg-gray-700 rounded mb-2"></div>
                      <div className="h-4 w-1/2 bg-primary/40 rounded"></div>
                    </div>
                  ))}
                </div>

                {/* Bottom toolbar */}
                <div className="absolute bottom-3 right-3 left-5">
                  <div className="flex justify-between items-center">
                    <div className="h-10 w-32 bg-primary rounded"></div>
                    <div className="flex space-x-2">
                      <div className="h-10 w-24 bg-gray-700 rounded"></div>
                      <div className="h-10 w-24 bg-primary/80 rounded"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile mockup */}
      <div className="absolute -bottom-8 -right-6 md:right-0">
        <div className="bg-gray-800 rounded-2xl shadow-xl overflow-hidden border-4 border-gray-700">
          <div className="relative h-[140px] md:h-[180px] w-[70px] md:w-[90px]">
            <div className="absolute top-0 left-0 right-0 h-4 bg-gray-700"></div>
            <div className="pt-4 h-full bg-gray-900 p-1">
              <div className="h-4 w-full bg-primary/30 rounded mb-2"></div>
              <div className="h-4 w-full bg-gray-800 rounded mb-2"></div>
              <div className="h-4 w-full bg-gray-800 rounded mb-2"></div>
              <div className="h-4 w-full bg-gray-800 rounded mb-2"></div>
              <div className="absolute bottom-2 left-0 right-0 px-1">
                <div className="h-6 w-full bg-primary rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      <div className="tmbill-gradient py-16 md:py-24">
        <div className="container grid gap-8 md:grid-cols-2 items-center">
          <div className="space-y-6 text-white">
            <h1 className="text-3xl md:text-5xl font-bold leading-tight">
              12,000+ Restaurants Trust TMBill for Seamless Operations
            </h1>
            <p className="text-lg md:text-xl opacity-90">
              Complete restaurant management solution with POS, inventory, online ordering, CRM, and loyalty - all in one platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90">
                Get Started Free
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                Book a Demo
              </Button>
            </div>
            <div className="pt-6">
              <p className="text-sm opacity-80 mb-3">Trusted by restaurants worldwide</p>
              <div className="flex flex-wrap gap-4 items-center">
                <div className="bg-white/10 px-3 py-2 rounded-md text-xs">
                  India
                </div>
                <div className="bg-white/10 px-3 py-2 rounded-md text-xs">
                  Saudi Arabia
                </div>
                <div className="bg-white/10 px-3 py-2 rounded-md text-xs">
                  UAE
                </div>
                <div className="bg-white/10 px-3 py-2 rounded-md text-xs">
                  UK
                </div>
                <div className="bg-white/10 px-3 py-2 rounded-md text-xs">
                  Oman
                </div>
                <div className="bg-white/10 px-3 py-2 rounded-md text-xs">
                  +20 more
                </div>
              </div>
            </div>
          </div>
          <ProductShowcase />
        </div>
      </div>

      {/* Features highlight */}
      <div className="container py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
          <div className="text-center space-y-2 p-4">
            <div className="text-primary font-bold text-xl md:text-3xl">24/7</div>
            <p className="text-gray-600 text-sm md:text-base">Customer Support</p>
          </div>
          <div className="text-center space-y-2 p-4">
            <div className="text-primary font-bold text-xl md:text-3xl">6000+</div>
            <p className="text-gray-600 text-sm md:text-base">Restaurants Globally</p>
          </div>
          <div className="text-center space-y-2 p-4">
            <div className="text-primary font-bold text-xl md:text-3xl">99.9%</div>
            <p className="text-gray-600 text-sm md:text-base">Uptime Guarantee</p>
          </div>
          <div className="text-center space-y-2 p-4">
            <div className="text-primary font-bold text-xl md:text-3xl">Free</div>
            <p className="text-gray-600 text-sm md:text-base">Starter Plan</p>
          </div>
        </div>
      </div>
    </section>
  );
}
