import React from "react";

interface TMBillLogoProps {
  className?: string;
}

export function TMBillLogo({ className = "" }: TMBillLogoProps) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="relative">
        <svg
          width="40"
          height="40"
          viewBox="0 0 40 40"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <circle cx="20" cy="20" r="20" fill="#28a497" />
          <path
            d="M12 14C12 12.8954 12.8954 12 14 12H26C27.1046 12 28 12.8954 28 14V26C28 27.1046 27.1046 28 26 28H14C12.8954 28 12 27.1046 12 26V14Z"
            fill="white"
          />
          <path
            d="M17 16H23M17 20H23M17 24H23"
            stroke="#28a497"
            strokeWidth="2"
            strokeLinecap="round"
          />
          <path
            d="M23 31C17.4772 31 13 26.5228 13 21C13 15.4772 17.4772 11 23 11"
            stroke="#a4dd91"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </svg>
      </div>
      <div className="font-bold text-2xl text-gray-800">
        TM<span className="text-primary">Bill</span>
      </div>
    </div>
  );
}
