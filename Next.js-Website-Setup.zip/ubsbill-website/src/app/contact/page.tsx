import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Mail, Phone, MapPin, Clock } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="bg-white">
      <div className="container-wide py-16 md:py-24">
        <div className="max-w-3xl mx-auto text-center mb-10">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl text-gray-900">Contact Us</h1>
          <p className="mt-4 text-lg text-gray-600">
            Have questions or need assistance? We're here to help! Reach out to our team using any of the options below.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 items-start">
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Send us a message</CardTitle>
                <CardDescription>Fill out the form below and we'll get back to you as soon as possible.</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-6">
                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                    <div className="space-y-2">
                      <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">
                        First name
                      </label>
                      <input
                        type="text"
                        id="first-name"
                        name="first-name"
                        autoComplete="given-name"
                        className="block w-full rounded-md border-gray-300 shadow-sm py-2 px-3 focus:border-primary focus:ring-primary text-sm"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="last-name" className="block text-sm font-medium text-gray-700">
                        Last name
                      </label>
                      <input
                        type="text"
                        id="last-name"
                        name="last-name"
                        autoComplete="family-name"
                        className="block w-full rounded-md border-gray-300 shadow-sm py-2 px-3 focus:border-primary focus:ring-primary text-sm"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      autoComplete="email"
                      className="block w-full rounded-md border-gray-300 shadow-sm py-2 px-3 focus:border-primary focus:ring-primary text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                      Phone number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      autoComplete="tel"
                      className="block w-full rounded-md border-gray-300 shadow-sm py-2 px-3 focus:border-primary focus:ring-primary text-sm"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="business-type" className="block text-sm font-medium text-gray-700">
                      Business Type
                    </label>
                    <select
                      id="business-type"
                      name="business-type"
                      className="block w-full rounded-md border-gray-300 shadow-sm py-2 px-3 focus:border-primary focus:ring-primary text-sm"
                    >
                      <option>Restaurant</option>
                      <option>Retail</option>
                      <option>Grocery</option>
                      <option>Cafe</option>
                      <option>Service</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                      Message
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={4}
                      className="block w-full rounded-md border-gray-300 shadow-sm py-2 px-3 focus:border-primary focus:ring-primary text-sm"
                    ></textarea>
                  </div>
                  <div>
                    <Button type="submit" className="w-full">
                      Send Message
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
                <CardDescription>Our team is ready to assist you with any questions or concerns.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4 items-start">
                  <Mail className="h-5 w-5 text-primary flex-shrink-0" />
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">Email</h3>
                    <p className="text-sm text-gray-600">contact@ubsbill.com</p>
                    <p className="text-sm text-gray-600">support@ubsbill.com</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <Phone className="h-5 w-5 text-primary flex-shrink-0" />
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">Phone</h3>
                    <p className="text-sm text-gray-600">+1 (800) 123-4567</p>
                    <p className="text-sm text-gray-600">+1 (800) 987-6543</p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <MapPin className="h-5 w-5 text-primary flex-shrink-0" />
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">Office</h3>
                    <p className="text-sm text-gray-600">
                      123 Business Street, Suite 100
                      <br />
                      San Francisco, CA 94103
                      <br />
                      United States
                    </p>
                  </div>
                </div>
                <div className="flex gap-4 items-start">
                  <Clock className="h-5 w-5 text-primary flex-shrink-0" />
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">Working Hours</h3>
                    <p className="text-sm text-gray-600">
                      Monday - Friday: 9:00 AM - 6:00 PM (PST)
                      <br />
                      Saturday: 10:00 AM - 2:00 PM (PST)
                      <br />
                      Sunday: Closed
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Frequently Asked Questions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-900">How do I request a demo?</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    You can request a demo by filling out the form on this page or calling our sales team directly.
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Is there a free trial available?</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Yes, we offer a 14-day free trial for all our plans with no credit card required.
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900">What support options are available?</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    We provide email, phone, and live chat support. Premium plans include priority support and dedicated account managers.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
