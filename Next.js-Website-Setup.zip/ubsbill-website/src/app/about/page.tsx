import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="hero-gradient text-white py-16 md:py-24">
        <div className="container-wide">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">About UBSBill</h1>
            <p className="mt-6 text-lg text-gray-100">
              UBSBill is a leading provider of point-of-sale software solutions, dedicated to helping businesses
              streamline their operations and grow their customer base.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16 md:py-24">
        <div className="container-wide">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Our Story</h2>
              <p className="mt-6 text-lg text-gray-600">
                UBSBill was founded in 2015 with a simple mission: to create a point-of-sale system that's powerful yet
                easy to use. Our founders recognized that small and medium-sized businesses were struggling with
                complex, outdated POS systems that were expensive and difficult to manage.
              </p>
              <p className="mt-4 text-lg text-gray-600">
                We set out to build a solution that would democratize access to advanced POS capabilities, making it
                possible for businesses of all sizes to benefit from modern technology without breaking the bank.
              </p>
              <p className="mt-4 text-lg text-gray-600">
                Today, UBSBill serves thousands of businesses across various industries, from restaurants and cafes to
                retail stores and service providers. Our platform continues to evolve, incorporating customer feedback
                and emerging technologies to provide the best possible experience.
              </p>
            </div>
            <div className="relative">
              <Image
                src="/images/ubsbill-pos-img.png"
                alt="UBSBill team working"
                width={600}
                height={600}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Values Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-wide">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Our Values</h2>
            <p className="mt-4 text-lg text-gray-600">
              At UBSBill, we're guided by a set of core values that shape everything we do, from product development to
              customer support.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Customer Success",
                description:
                  "We're not successful unless our customers are. We prioritize their needs and measure our success by their achievements.",
              },
              {
                title: "Innovation",
                description:
                  "We're constantly exploring new technologies and approaches to improve our products and services.",
              },
              {
                title: "Simplicity",
                description:
                  "We believe powerful technology doesn't have to be complicated. We strive for elegant, intuitive solutions.",
              },
              {
                title: "Transparency",
                description:
                  "We're open and honest in all our dealings, with clear pricing, straightforward terms, and direct communication.",
              },
              {
                title: "Quality",
                description:
                  "We're committed to excellence in everything we do, from code quality to customer support interactions.",
              },
              {
                title: "Inclusivity",
                description:
                  "We create products that work for businesses of all sizes and individuals from all backgrounds.",
              },
            ].map((value) => (
              <Card key={value.title} className="border-none shadow-md">
                <CardContent className="pt-6">
                  <CheckCircle2 className="h-10 w-10 text-primary mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16">
        <div className="container-wide">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Our Leadership Team</h2>
            <p className="mt-4 text-lg text-gray-600">
              Meet the experienced professionals guiding UBSBill's mission to transform the POS industry.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                name: "Michael Roberts",
                role: "CEO & Co-Founder",
                bio: "Michael brings over 15 years of experience in software development and business management.",
              },
              {
                name: "Jennifer Zhang",
                role: "CTO & Co-Founder",
                bio: "Jennifer is an expert in cloud architecture and leads UBSBill's technical innovation.",
              },
              {
                name: "David Patel",
                role: "VP of Product",
                bio: "David oversees product strategy and ensures our solutions meet real customer needs.",
              },
              {
                name: "Sarah Johnson",
                role: "VP of Customer Success",
                bio: "Sarah leads our customer success team and ensures clients get maximum value from UBSBill.",
              },
            ].map((member) => (
              <div key={member.name} className="text-center">
                <div className="w-32 h-32 bg-gray-200 rounded-full mx-auto mb-4"></div>
                <h3 className="text-lg font-semibold text-gray-900">{member.name}</h3>
                <p className="text-sm text-primary font-medium mb-2">{member.role}</p>
                <p className="text-gray-600 text-sm">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Careers Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-wide">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Join Our Team</h2>
            <p className="mt-4 text-lg text-gray-600">
              We're always looking for talented individuals to help us achieve our mission. Check out our open positions
              and become part of our journey.
            </p>
            <div className="mt-8">
              <Button size="lg">View Open Positions</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="hero-gradient text-white py-16">
        <div className="container-wide">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Ready to get started?</h2>
            <p className="mt-6 text-lg text-gray-100">
              Join thousands of businesses that trust UBSBill for their POS needs. Start your 14-day free trial today.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                Get Started
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                Contact Sales
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
