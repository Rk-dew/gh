import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Check, ArrowRight, Star } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="hero-gradient text-white py-16 md:py-24">
        <div className="container-wide">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
                Everything you need to manage your business in one place
              </h1>
              <p className="text-lg md:text-xl text-gray-100">
                UBSBill POS simplifies your business operations with a powerful, easy-to-use point of sale system designed for modern businesses.
              </p>
              <div className="pt-4 flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                  Get Started
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                  Watch Demo
                </Button>
              </div>
              <div className="pt-6 flex flex-col sm:flex-row items-start sm:items-center gap-4 text-sm">
                <div className="flex items-center gap-1">
                  <Check className="h-5 w-5 text-primary-foreground" />
                  <span>No credit card required</span>
                </div>
                <div className="flex items-center gap-1">
                  <Check className="h-5 w-5 text-primary-foreground" />
                  <span>Free 14-day trial</span>
                </div>
                <div className="flex items-center gap-1">
                  <Check className="h-5 w-5 text-primary-foreground" />
                  <span>24/7 Support</span>
                </div>
              </div>
            </div>
            <div className="hidden lg:block lg:relative">
              <Image
                src="/images/ubsbill-banner.png"
                alt="UBSBill POS Software on multiple devices"
                width={600}
                height={400}
                className="rounded-lg shadow-xl"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 bg-white" id="pricing">
        <div className="container-wide">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Choose your perfect plan</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Select the plan that's right for your business. All plans include a 14-day free trial.
            </p>
          </div>

          <Tabs defaultValue="monthly" className="w-full max-w-3xl mx-auto">
            <div className="flex justify-center mb-8">
              <TabsList>
                <TabsTrigger value="monthly">Monthly Billing</TabsTrigger>
                <TabsTrigger value="yearly">Yearly Billing (Save 20%)</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="monthly" className="space-y-8">
              <div className="grid md:grid-cols-3 gap-8">
                {/* Basic Plan */}
                <Card className="pricing-card">
                  <CardHeader>
                    <CardTitle>Basic</CardTitle>
                    <div className="mt-4">
                      <span className="text-3xl font-bold">$29</span>
                      <span className="text-gray-500 ml-2">/month</span>
                    </div>
                    <CardDescription>Perfect for small businesses</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {["1 Outlet", "2 Users", "Basic Reports", "Cloud Storage", "Email Support", "Mobile App Access"].map((feature) => (
                        <li key={feature} className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-primary flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">Choose Basic</Button>
                  </CardFooter>
                </Card>

                {/* Pro Plan */}
                <Card className="pricing-card-featured">
                  <div className="absolute top-0 right-0 bg-primary text-white px-3 py-1 text-xs font-medium rounded-bl-lg rounded-tr-lg">
                    POPULAR
                  </div>
                  <CardHeader>
                    <CardTitle>Pro</CardTitle>
                    <div className="mt-4">
                      <span className="text-3xl font-bold">$49</span>
                      <span className="text-gray-500 ml-2">/month</span>
                    </div>
                    <CardDescription>Ideal for growing businesses</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {[
                        "3 Outlets",
                        "5 Users",
                        "Advanced Reports",
                        "Cloud Storage",
                        "Priority Support",
                        "Mobile App Access",
                        "Inventory Management",
                        "Customer Management",
                      ].map((feature) => (
                        <li key={feature} className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-primary flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Choose Pro</Button>
                  </CardFooter>
                </Card>

                {/* Enterprise Plan */}
                <Card className="pricing-card">
                  <CardHeader>
                    <CardTitle>Enterprise</CardTitle>
                    <div className="mt-4">
                      <span className="text-3xl font-bold">$99</span>
                      <span className="text-gray-500 ml-2">/month</span>
                    </div>
                    <CardDescription>For large business operations</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {[
                        "Unlimited Outlets",
                        "Unlimited Users",
                        "Custom Reports",
                        "Enhanced Security",
                        "24/7 Premium Support",
                        "Mobile App Access",
                        "Advanced Inventory",
                        "Advanced CRM",
                        "API Access",
                        "Custom Integrations",
                      ].map((feature) => (
                        <li key={feature} className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-primary flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">Choose Enterprise</Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="yearly" className="space-y-8">
              <div className="grid md:grid-cols-3 gap-8">
                {/* Basic Plan Yearly */}
                <Card className="pricing-card">
                  <CardHeader>
                    <CardTitle>Basic</CardTitle>
                    <div className="mt-4">
                      <span className="text-3xl font-bold">$279</span>
                      <span className="text-gray-500 ml-2">/year</span>
                    </div>
                    <CardDescription>Perfect for small businesses</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {["1 Outlet", "2 Users", "Basic Reports", "Cloud Storage", "Email Support", "Mobile App Access"].map((feature) => (
                        <li key={feature} className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-primary flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">Choose Basic</Button>
                  </CardFooter>
                </Card>

                {/* Pro Plan Yearly */}
                <Card className="pricing-card-featured">
                  <div className="absolute top-0 right-0 bg-primary text-white px-3 py-1 text-xs font-medium rounded-bl-lg rounded-tr-lg">
                    POPULAR
                  </div>
                  <CardHeader>
                    <CardTitle>Pro</CardTitle>
                    <div className="mt-4">
                      <span className="text-3xl font-bold">$469</span>
                      <span className="text-gray-500 ml-2">/year</span>
                    </div>
                    <CardDescription>Ideal for growing businesses</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {[
                        "3 Outlets",
                        "5 Users",
                        "Advanced Reports",
                        "Cloud Storage",
                        "Priority Support",
                        "Mobile App Access",
                        "Inventory Management",
                        "Customer Management",
                      ].map((feature) => (
                        <li key={feature} className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-primary flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Choose Pro</Button>
                  </CardFooter>
                </Card>

                {/* Enterprise Plan Yearly */}
                <Card className="pricing-card">
                  <CardHeader>
                    <CardTitle>Enterprise</CardTitle>
                    <div className="mt-4">
                      <span className="text-3xl font-bold">$950</span>
                      <span className="text-gray-500 ml-2">/year</span>
                    </div>
                    <CardDescription>For large business operations</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {[
                        "Unlimited Outlets",
                        "Unlimited Users",
                        "Custom Reports",
                        "Enhanced Security",
                        "24/7 Premium Support",
                        "Mobile App Access",
                        "Advanced Inventory",
                        "Advanced CRM",
                        "API Access",
                        "Custom Integrations",
                      ].map((feature) => (
                        <li key={feature} className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-primary flex-shrink-0" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">Choose Enterprise</Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container-wide">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Why choose UBSBill?</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Streamline your business operations with our advanced POS system designed to boost efficiency and sales.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "User-Friendly Interface",
                description: "Intuitive design that's easy to learn and use, reducing training time for your staff.",
              },
              {
                title: "Cloud-Based Solution",
                description: "Access your business data from anywhere, on any device, at any time.",
              },
              {
                title: "Real-Time Analytics",
                description: "Get instant insights into your business performance with comprehensive reports.",
              },
              {
                title: "Inventory Management",
                description: "Keep track of your stock levels and get alerts when it's time to reorder.",
              },
              {
                title: "Customer Management",
                description: "Build better relationships with your customers by tracking their preferences and purchase history.",
              },
              {
                title: "Seamless Integrations",
                description: "Connect with your favorite tools and platforms for a complete business solution.",
              },
            ].map((feature, index) => (
              <Card key={index} className="border-none shadow-md hover:shadow-xl transition-shadow">
                <CardHeader>
                  <CardTitle>{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-white">
        <div className="container-wide">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">What our customers say</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Join thousands of satisfied businesses who trust UBSBill for their POS needs.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                quote: "UBSBill has completely transformed how we manage our cafe. The inventory tracking alone has saved us hours each week.",
                author: "Sarah Johnson",
                role: "Cafe Owner",
                rating: 5,
              },
              {
                quote: "I was surprised by how easy it was to set up and train my staff. The interface is intuitive and the support team is always helpful.",
                author: "Michael Chen",
                role: "Retail Store Manager",
                rating: 5,
              },
              {
                quote: "The analytics feature has been a game-changer for our business decisions. We can now see what products are performing well in real-time.",
                author: "Emma Wilson",
                role: "Boutique Owner",
                rating: 4,
              },
            ].map((testimonial, index) => (
              <Card key={index} className="border shadow-md hover:shadow-lg transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex">
                    {Array(testimonial.rating)
                      .fill(0)
                      .map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                      ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 italic mb-4">"{testimonial.quote}"</p>
                  <div>
                    <p className="font-medium text-gray-900">{testimonial.author}</p>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button variant="outline" className="group">
              Read more reviews
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="hero-gradient text-white py-16">
        <div className="container-wide">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">Ready to streamline your business?</h2>
              <p className="text-lg text-gray-100 mb-8">
                Join thousands of businesses that trust UBSBill for their POS needs. Start your 14-day free trial today.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                  Get Started
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                  Contact Sales
                </Button>
              </div>
            </div>
            <div className="hidden lg:block relative">
              <Image
                src="/images/ubsbill-pos-img.png"
                alt="UBS Bill POS Illustration"
                width={500}
                height={500}
                className="mx-auto"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
