import Link from "next/link"
import Image from "next/image"
import { Facebook, Twitter, Instagram, Linkedin, Mail, PhoneCall } from "lucide-react"

const footerNavigation = {
  products: [
    { name: "POS Software", href: "/products/pos-software" },
    { name: "Billing Solutions", href: "/products/billing-solutions" },
    { name: "Inventory Management", href: "/products/inventory-management" },
    { name: "Customer Management", href: "/products/customer-management" },
  ],
  features: [
    { name: "Cloud-Based POS", href: "/features/cloud-based-pos" },
    { name: "Multi-Outlet Management", href: "/features/multi-outlet-management" },
    { name: "Analytics & Reporting", href: "/features/analytics-reporting" },
    { name: "Mobile Access", href: "/features/mobile-access" },
  ],
  company: [
    { name: "About", href: "/about" },
    { name: "Careers", href: "/careers" },
    { name: "Blog", href: "/blog" },
    { name: "Press", href: "/press" },
  ],
  legal: [
    { name: "Privacy Policy", href: "/legal/privacy-policy" },
    { name: "Terms of Service", href: "/legal/terms-of-service" },
    { name: "Cookie Policy", href: "/legal/cookie-policy" },
  ],
  support: [
    { name: "Help Center", href: "/support/help-center" },
    { name: "Contact Us", href: "/contact" },
    { name: "FAQ", href: "/support/faq" },
    { name: "System Status", href: "/support/system-status" },
  ],
}

const socialLinks = [
  { name: "Facebook", icon: Facebook, href: "https://facebook.com" },
  { name: "Twitter", icon: Twitter, href: "https://twitter.com" },
  { name: "Instagram", icon: Instagram, href: "https://instagram.com" },
  { name: "LinkedIn", icon: Linkedin, href: "https://linkedin.com" },
]

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200" aria-labelledby="footer-heading">
      <h2 id="footer-heading" className="sr-only">
        Footer
      </h2>
      <div className="container-wide py-12 md:py-16">
        <div className="xl:grid xl:grid-cols-5 xl:gap-8">
          <div className="space-y-8 xl:col-span-1">
            <Link href="/">
              <Image
                src="/images/ubsbill-logo.png"
                alt="UBSBill Logo"
                width={120}
                height={32}
                className="h-8 w-auto"
              />
            </Link>
            <p className="text-sm text-gray-600 max-w-xs">
              UBSBill provides innovative POS software solutions for businesses of all sizes to streamline operations and boost productivity.
            </p>
            <div className="flex space-x-5">
              {socialLinks.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-gray-500 hover:text-primary"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <span className="sr-only">{item.name}</span>
                  <item.icon className="h-5 w-5" aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-8 xl:col-span-4 xl:mt-0">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-gray-900">Products</h3>
                <ul role="list" className="mt-4 space-y-3">
                  {footerNavigation.products.map((item) => (
                    <li key={item.name}>
                      <Link href={item.href} className="footer-link">
                        {item.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-10 md:mt-0">
                <h3 className="text-sm font-semibold text-gray-900">Features</h3>
                <ul role="list" className="mt-4 space-y-3">
                  {footerNavigation.features.map((item) => (
                    <li key={item.name}>
                      <Link href={item.href} className="footer-link">
                        {item.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold text-gray-900">Company</h3>
                <ul role="list" className="mt-4 space-y-3">
                  {footerNavigation.company.map((item) => (
                    <li key={item.name}>
                      <Link href={item.href} className="footer-link">
                        {item.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-10 md:mt-0">
                <h3 className="text-sm font-semibold text-gray-900">Support</h3>
                <ul role="list" className="mt-4 space-y-3">
                  {footerNavigation.support.map((item) => (
                    <li key={item.name}>
                      <Link href={item.href} className="footer-link">
                        {item.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-gray-200 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0">
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <PhoneCall className="h-4 w-4 text-gray-500" />
                <span className="text-sm text-gray-500">+1 (800) 123-4567</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-gray-500" />
                <span className="text-sm text-gray-500">contact@ubsbill.com</span>
              </div>
            </div>
            <div className="flex flex-col md:flex-row md:items-center space-y-2 md:space-y-0 md:space-x-6">
              {footerNavigation.legal.map((item) => (
                <Link key={item.name} href={item.href} className="footer-link">
                  {item.name}
                </Link>
              ))}
            </div>
          </div>
          <p className="mt-8 text-xs text-gray-500">&copy; {new Date().getFullYear()} UBSBill. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
