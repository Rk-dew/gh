import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChevronDown, Menu, X } from "lucide-react"
import { useState } from "react"

const navigation = [
  { name: "Home", href: "/" },
  {
    name: "Products",
    href: "#",
    children: [
      { name: "POS Software", href: "/products/pos-software" },
      { name: "Billing Solutions", href: "/products/billing-solutions" },
      { name: "Inventory Management", href: "/products/inventory-management" },
      { name: "Customer Management", href: "/products/customer-management" },
    ],
  },
  {
    name: "Features",
    href: "#",
    children: [
      { name: "Cloud-Based POS", href: "/features/cloud-based-pos" },
      { name: "Multi-Outlet Management", href: "/features/multi-outlet-management" },
      { name: "Analytics & Reporting", href: "/features/analytics-reporting" },
      { name: "Mobile Access", href: "/features/mobile-access" },
    ],
  },
  { name: "Pricing", href: "/pricing" },
  { name: "About", href: "/about" },
  { name: "Contact", href: "/contact" },
]

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <nav className="container-wide flex items-center justify-between py-4">
        {/* Logo */}
        <div className="flex items-center">
          <Link href="/" className="flex-shrink-0">
            <Image
              src="/images/ubsbill-logo.png"
              alt="UBSBill Logo"
              width={150}
              height={40}
              className="h-9 w-auto"
              priority
            />
          </Link>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex lg:gap-x-8">
          {navigation.map((item) => (
            !item.children ? (
              <Link
                key={item.name}
                href={item.href}
                className="text-sm font-medium text-gray-700 hover:text-primary transition-colors"
              >
                {item.name}
              </Link>
            ) : (
              <DropdownMenu key={item.name}>
                <DropdownMenuTrigger asChild>
                  <button className="inline-flex items-center gap-x-1 text-sm font-medium text-gray-700 hover:text-primary transition-colors">
                    {item.name}
                    <ChevronDown className="h-4 w-4" aria-hidden="true" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-48">
                  {item.children.map((child) => (
                    <DropdownMenuItem key={child.name} asChild>
                      <Link href={child.href} className="w-full">
                        {child.name}
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="hidden lg:flex lg:flex-1 lg:items-center lg:justify-end lg:gap-x-4">
          <Link href="/login" className="text-sm font-medium text-gray-700 hover:text-primary transition-colors">
            Login
          </Link>
          <Button size="sm">Get Started</Button>
        </div>

        {/* Mobile menu button */}
        <div className="flex lg:hidden">
          <button
            type="button"
            className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700"
            onClick={() => setMobileMenuOpen(true)}
          >
            <span className="sr-only">Open main menu</span>
            <Menu className="h-6 w-6" aria-hidden="true" />
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-white">
          <div className="fixed inset-0 z-50">
            <div className="p-4 flex justify-between items-center border-b">
              <Link href="/" className="-m-1.5 p-1.5" onClick={() => setMobileMenuOpen(false)}>
                <Image
                  src="/images/ubsbill-logo.png"
                  alt="UBSBill Logo"
                  width={150}
                  height={40}
                  className="h-8 w-auto"
                />
              </Link>
              <button
                type="button"
                className="-m-2.5 rounded-md p-2.5 text-gray-700"
                onClick={() => setMobileMenuOpen(false)}
              >
                <span className="sr-only">Close menu</span>
                <X className="h-6 w-6" aria-hidden="true" />
              </button>
            </div>
            <div className="mt-6 flow-root">
              <div className="divide-y divide-gray-200">
                <div className="py-3 px-4 space-y-4">
                  {navigation.map((item) => (
                    <div key={item.name}>
                      {!item.children ? (
                        <Link
                          href={item.href}
                          className="block text-base font-medium text-gray-900 hover:text-primary transition-colors"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          {item.name}
                        </Link>
                      ) : (
                        <div className="space-y-2">
                          <div className="text-base font-medium text-gray-900">{item.name}</div>
                          <div className="ml-4 space-y-2">
                            {item.children.map((child) => (
                              <Link
                                key={child.name}
                                href={child.href}
                                className="block text-sm text-gray-600 hover:text-primary transition-colors"
                                onClick={() => setMobileMenuOpen(false)}
                              >
                                {child.name}
                              </Link>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                <div className="py-6 px-4 flex flex-col space-y-4">
                  <Link
                    href="/login"
                    className="text-base font-medium text-gray-900 hover:text-primary transition-colors"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Login
                  </Link>
                  <Button onClick={() => setMobileMenuOpen(false)}>Get Started</Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
